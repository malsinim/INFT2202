# INFT2202 ICE10 Starter Code

This is the starter code for ICE10. You will need to create additional models and connect them to the exiting controllers and views.
