exports.userView = (req, res) => {
  res.render('home');
}