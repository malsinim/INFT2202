
exports.homeView = (req, res) => {
  res.render('home');
};

exports.aboutView = (req, res) => {
  res.render('about');
};

exports.pricingView = (req, res) => {
  res.render('pricing');
};

exports.servicesView = (req, res) => {
  res.render('services');
};

exports.productsView = (req, res) => {
  res.render('products');
};
